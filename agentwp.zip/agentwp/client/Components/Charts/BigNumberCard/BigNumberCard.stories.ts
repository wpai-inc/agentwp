import BigNumberCard from './BigNumberCard';

export default {
  title: 'Wpai/Charts/BigNumberCard',
  component: BigNumberCard,
};

export const Simple = {
  args: {
    data: [ { label: 'Honduras', developers: 40 } ],
  },
};
