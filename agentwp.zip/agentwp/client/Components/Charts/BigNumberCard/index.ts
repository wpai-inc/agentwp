import BigNumberCard from './BigNumberCard';
export default BigNumberCard;
