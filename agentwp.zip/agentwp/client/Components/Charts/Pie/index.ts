import Pie from './Pie';
export default Pie;
