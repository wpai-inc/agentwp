import NavigatableButton from './NavigatableButton';
export default NavigatableButton;
