import TabContainer from './TabContainer';

export default function SettingsTab() {
  return <TabContainer>SettingsTab</TabContainer>;
}
