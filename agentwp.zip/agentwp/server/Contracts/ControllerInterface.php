<?php

namespace WpAi\AgentWp\Contracts;

interface ControllerInterface
{
    public function method(): RouteMethods;
}
